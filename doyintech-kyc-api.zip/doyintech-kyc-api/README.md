# DoyinTech KYC API

**Production-ready Nigerian Identity Verification API** by [DoyinTech](https://doyintech.vercel.app)

Supports:
- BVN Verification
- NIN Verification
- Document Verification (Passport, Driver’s License, Voter’s Card, National ID)
- Face Match

Built for fintechs, proptech, lending platforms, and marketplaces.

---

## Quick Start

```bash
# Install
npm install

# Copy environment
cp .env.example .env

# Development
npm run dev

# Production build
npm run build && npm start
```

## Authentication

All `/v1/kyc/*` endpoints require an API key:

```
X-API-Key: your-api-key-here
```

Set valid keys in `.env`:
```
API_KEYS=key1,key2,key3
```

## Endpoints

| Method | Endpoint              | Description                  |
|--------|-----------------------|------------------------------|
| GET    | `/health`             | Health check                 |
| POST   | `/v1/kyc/bvn`         | Verify BVN                   |
| POST   | `/v1/kyc/nin`         | Verify NIN                   |
| POST   | `/v1/kyc/document`    | Verify identity document     |
| POST   | `/v1/kyc/face-match`  | Compare two face images      |

### Example – BVN

```bash
curl -X POST http://localhost:4000/v1/kyc/bvn \
  -H "Content-Type: application/json" \
  -H "X-API-Key: dev-key-123" \
  -d '{"bvn": "12345678901", "firstName": "Adebayo"}'
```

## Pricing Model Suggestion

| Plan          | Monthly Fee | Verifications included | Overage          |
|---------------|-------------|------------------------|------------------|
| Starter       | ₦15,000     | 500                    | ₦80 / verification |
| Growth        | ₦45,000     | 2,000                  | ₦60 / verification |
| Business      | ₦120,000    | 10,000                 | ₦40 / verification |
| Enterprise    | Custom      | Unlimited              | Negotiated       |

## Production Notes

- Replace the mock logic in `src/services/verification.ts` with real providers (Smile Identity, Youverify, Prembly, Mono, etc.)
- Add Redis for rate limiting & caching
- Add request logging + audit trail
- Add webhook support for async verification
- Deploy behind API Gateway (AWS, Cloudflare, or Kong)

## Author

**Silas Doyin Jonathan**  
DoyinTech — Scalable Backend, APIs & Mobile Development  
https://doyintech.vercel.app

---

© 2026 DoyinTech. All rights reserved.
